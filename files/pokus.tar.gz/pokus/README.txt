---------
Overview:
---------

A module pokus.


--------
Authors:
--------

Ivo Musil (im@atlas.cz)
