<?php
	$vars = get_defined_vars();
	$view = get_artx_drupal_view();
	$view->print_comment($vars);
?>